import java.util.Scanner;

public class HitungCat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Masukkan tinggi ruangan (kaki): ");
        double tinggi = scanner.nextDouble();
        
        System.out.print("Masukkan panjang ruangan (kaki): ");
        double panjang = scanner.nextDouble();
        
        System.out.print("Masukkan lebar ruangan (kaki): ");
        double lebar = scanner.nextDouble();
        
        // Menghitung luas permukaan yang akan dicat (4 dinding + 1 langit-langit, tanpa lantai)
        double luasDinding = 2 * (panjang * tinggi) + 2 * (lebar * tinggi);
        double luasLangitLangit = panjang * lebar;
        double totalLuas = luasDinding + luasLangitLangit;
        
        System.out.println("Total luas permukaan yang harus dicat: " + totalLuas + " kaki persegi.");
        
        // Menghitung kebutuhan cat optimal (Ember 5 liter = 1500 sq ft seharga $15, Ember 1 liter = 300 sq ft seharga $4)
        // Kita prioritaskan penggunaan ember 5 liter terlebih dahulu agar lebih ekonomis
        int ember5Liter = (int) (totalLuas / 1500);
        double sisaLuas = totalLuas % 1500;
        
        int ember1Liter = (int) Math.ceil(sisaLuas / 300.0);
        
        // Penyesuaian jika pembelian 1 liter melebihi atau sama efisiennya dengan menambah ember 5 liter
        if (ember1Liter >= 5) {
            ember5Liter += 1;
            ember1Liter = 0;
        }
        
        double totalBiaya = (ember5Liter * 15.0) + (ember1Liter * 4.0);
        
        System.out.println("Rekomendasi pembelian cat optimal:");
        System.out.println("- Ember 5 liter (1500 sq ft / $15): " + ember5Liter);
        System.out.println("- Ember 1 liter (300 sq ft / $4): " + ember1Liter);
        System.out.println("Total biaya yang harus dikeluarkan: $" + totalBiaya);
    }
}