import java.util.Scanner;

public class SeleksiUniversitas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Apakah mahasiswa merupakan valedictorian atau salutatorian? (true/false): ");
        boolean isValOrSal = scanner.nextBoolean();
        
        System.out.print("Masukkan jumlah total siswa di sekolah: ");
        int jumlahSiswa = scanner.nextInt();
        
        System.out.print("Masukkan GPA mahasiswa: ");
        double gpa = scanner.nextDouble();
        
        System.out.print("Masukkan skor SAT mahasiswa: ");
        int satScore = scanner.nextInt();
        
        // Memeriksa kriteria penerimaan
        boolean diterima = false;
        
        if (isValOrSal && jumlahSiswa >= 1400) {
            diterima = true;
        } else if (gpa >= 4.0 && satScore >= 1100) {
            diterima = true;
        } else if (gpa >= 3.5 && satScore >= 1300) {
            diterima = true;
        } else if (gpa >= 3.0 && satScore >= 1500) {
            diterima = true;
        }
        
        if (diterima) {
            System.out.println("Selamat! Mahasiswa DITERIMA di Mountville University.");
        } else {
            System.out.println("Mohon maaf, mahasiswa belum memenuhi kriteria penerimaan.");
        }
    }
}