public class HariDalamSetahun {
    public static void main(String[] args) {
        // Array untuk menyimpan nama-nama hari
        String[] daftarHari = {"Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"};
        
        System.out.println("Memulai perulangan untuk 365 hari dalam setahun:");
        
        // Menggunakan for loop karena jumlah perulangan sudah pasti (365 kali)
        for (int hariKe = 1; hariKe <= 365; hariKe++) {
            // Menentukan indeks hari secara berulang (0 sampai 6) menggunakan operator modulus (%)
            String namaHari = daftarHari[(hariKe - 1) % 7];
            
            System.out.println("Hari ke-" + hariKe + " adalah hari " + namaHari);
        }
    }
}