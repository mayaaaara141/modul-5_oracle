import java.util.Scanner;
import java.util.Arrays;

public class CekAnagram {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Masukkan string pertama: ");
        String str1 = scanner.nextLine();
        
        System.out.print("Masukkan string kedua: ");
        String str2 = scanner.nextLine();
        
        if (isAnagram(str1, str2)) {
            System.out.println("Hasil: Kedua string adalah ANAGRAM.");
        } else {
            System.out.println("Hasil: Kedua string BUKAN anagram.");
        }
    }
    
    public static boolean isAnagram(String s1, String s2) {
        // Membersihkan spasi, tanda baca, dan menyamakan huruf menjadi lowercase
        String clean1 = s1.replaceAll("[^a-zA-Z]", "").toLowerCase();
        String clean2 = s2.replaceAll("[^a-zA-Z]", "").toLowerCase();
        
        if (clean1.length() != clean2.length()) {
            return false;
        }
        
        char[] charArray1 = clean1.toCharArray();
        char[] charArray2 = clean2.toCharArray();
        
        Arrays.sort(charArray1);
        Arrays.sort(charArray2);
        
        return Arrays.equals(charArray1, charArray2);
    }
}